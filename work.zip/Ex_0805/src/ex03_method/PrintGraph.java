package ex03_method;

public class PrintGraph {
	public void print(int[] arr) {
		
		for (int i = 0; i < 10 ; i++) {
			int count = 0;
			for (int j = 0; j < 100; j++) {
				if (arr[j] == i) {
					count++;
				}	
			}
			System.out.print(i + "의 개수 : ");
			for (int j = 0; j < count; j++) {
				System.out.print("#");
				
			}
			System.out.printf(" %d",count);
			System.out.println();
		}
		
	}
}
