package ex03_method;

public class TimesTable {
	//TimesTable 클래스에서 showTable()메서드를 정의한다.
	//showTable() 메서드는 구구단을 출력하는 코드를 작성한다.
	//TimesTableMain클래스에서 키보드에서 정수를 하나 입력받아
	//입력받은 정수의 구구단을 출력하기
	
	public void showTable(int num) {
		for(int i = 1; i <= 9 ; i++) {
			System.out.printf("%d * %d = %d\n",num,i,(num*i));
		}
		
		
		
		
		
		
		
		
		
	}
}
