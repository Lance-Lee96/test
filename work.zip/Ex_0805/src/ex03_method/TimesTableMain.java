package ex03_method;

import java.util.Scanner;

public class TimesTableMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("단을 입력하세요 : ");
		int num = sc.nextInt();
		TimesTable table = new TimesTable();
		table.showTable(num);
	}
}
