package ex03_method;

import java.util.Random;

public class Graph {
	// Graph라는 이름의 클래스에 main() 메서드를 만들고
	// 0 ~ 9 사이의 난수를 100개 저장하는 배열을 만들고
	// 해당 배열이 가지고 있는 각 방의 난수를 판별하여 그래프화 해보자
	// 단, 발생한 난수의 그래프화 작업은 PrintGraph 클래스가 한다.
	public static void main(String[] args) {
		int arr[];
		arr = new int[100];
		for(int i = 0; i < arr.length; i++) {
			Random rnd = new Random();
			arr[i] = rnd.nextInt(10);	
		}
		System.out.println();
		PrintGraph graph = new PrintGraph();
		graph.print(arr);
	}
}
