package ex03_method;

import java.util.Scanner;

public class StartMain {
	public static void main(String[] args) {
		
		Start start = new Start();
		Scanner sc = new Scanner(System.in);
		System.out.println("정수를 입력하세요 : ");
		int num = sc.nextInt();
		int count = start.def();
		System.out.println(count + "번 만에 맞추셨습니다.");
				
	}
}
