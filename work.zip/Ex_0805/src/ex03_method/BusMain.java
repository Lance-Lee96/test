package ex03_method;

public class BusMain {
	public static void main(String[] args) {
		int money = 10000;
		Bus bus = new Bus();
		bus.take(money);
		
	}
}
