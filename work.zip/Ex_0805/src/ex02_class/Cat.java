package ex02_class;

public class Cat {
	//main 적지 않음
}
