package ex04_inheritance;

public class Book {
	String title;
	int price;
	
	void info() {
		System.out.println("책 제목은 : " + title + "이고, 가격은 " + price + "원입니다.");
	}
}
