package ex04_inheritance;

public class BookMain {

}
