package ex05_overriding;

public class CalMain {
	public static void main(String[] args) {
		CalPlus p = new CalPlus();
		CalMinus n = new CalMinus();
		
		int a = p.getResult(10, 20);
		int b = n.getResult(30, 15);
		System.out.println("CalPlus : " + a);
		System.out.println("CalMinus : " + b);
	}
}
