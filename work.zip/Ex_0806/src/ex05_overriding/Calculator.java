package ex05_overriding;

public class Calculator {
	//Calculator 클래스를 만들고
	//getResult()함수를 정의하세요
	//반환형 : 정수
	//매개변수 : int n1, int n2
	//반환값 : -1
	
	//CalPlus클래스를 만들고 Calculator를 상속받기
	//getResult()를 오버라이드 하여 두 수를 더하여 반환하는 메서드 만들기
	//CalMinus클래스를 만들고 Calculator를 상속받기
	//getResult()를 오버라이드 하여 두 수를 빼서 반환하는 메서드 만들기
	//CalMain 클래스를 만들고 실행하여 아래와 같은 결과 출력하기
	//CalPlus : 30
	//CalMinus : 15
	
	int getResult(int n1, int n2) {
		
		return -1;
	}
	
	
	
}
