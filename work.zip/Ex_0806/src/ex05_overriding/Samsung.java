package ex05_overriding;

public class Samsung extends Computer {
	
	//오버라이드		오버로드
	//재정의			중복정의
	
	
	
	
	
	@Override
	void powerOn() {
		//같은 메서드이지만 자식클래스의 상황에 맞게 재정의 하는 것
		System.out.println("I love Samsung");
	}
	
	
	
	
	
}
